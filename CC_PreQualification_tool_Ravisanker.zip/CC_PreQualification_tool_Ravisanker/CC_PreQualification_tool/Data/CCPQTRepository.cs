﻿using CC_PreQualification_tool.Models;
using CC_PreQualification_tool.Service;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CC_PreQualification_tool.Data
{
    ///<inheritdoc cref="ICCPQTRepository"/>
    public class CCPQTRepository : ICCPQTRepository
    {
        private readonly CCPTDBContext _ctx;
        private readonly ILogger<CCPQTRepository> _logger;
       

        /// <summary>
        /// Constructor Injection - DBContext and Logger
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="logger"></param>
        public CCPQTRepository(CCPTDBContext ctx, ILogger<CCPQTRepository> logger)
        {
            _ctx = ctx;
            _logger = logger;
        }

        /// <summary>
        /// Insert data to Customer table
        /// </summary>
        /// <param name="customer"></param>
        public void AddCustomer(Customer customer)
        {
            try
            {
                _logger.LogInformation("AddCustomer was called");

                _ctx.Customer.Add(customer);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to add the Customer Details: {ex}");

            }
           
        }

        /// <summary>
        /// Insert Data to CustomerCardDetails table
        /// </summary>
        /// <param name="ccDetails"></param>
        public void AddCustomerCardDetails(CustomerCardDetails ccDetails)
        {
            try
            {
                _logger.LogInformation("AddCustomerCardDetails was called");

                _ctx.CustomerCardDetails.Add(ccDetails);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to add the Customer Card Details: {ex}");
               
            }
           
        }

        /// <summary>
        /// Fetch the Card type from CreditCardType lookup table
        /// </summary>
        /// <returns></returns>
        public IEnumerable<CreditCardType> GetCardTypes()
        {
            return _ctx.CreditCardType.ToList();
        }

        /// <summary>
        /// Fetch the Customer Card details based on the Id 
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public IEnumerable<CustomerCardDetails> GetCustomerCardDetails(long Id)
        {
            return _ctx.CustomerCardDetails.Where(x=>x.Id == Id).ToList();
        }

        /// <summary>
        /// Get details from Customer table
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Customer> GetCustomerDetails()
        {
            try
            {
                _logger.LogInformation("GetCustomerDetails was called");

                return _ctx.Customer
                           .OrderBy(p => p.FirstName)
                           .ToList();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to get the Customer details: {ex}");
                return null;
            }
        }

        /// <summary>
        /// Save DBContext changes
        /// </summary>
        /// <returns></returns>
        public bool SaveAll()
        {
            return _ctx.SaveChanges() > 0;
        }
    }
}
