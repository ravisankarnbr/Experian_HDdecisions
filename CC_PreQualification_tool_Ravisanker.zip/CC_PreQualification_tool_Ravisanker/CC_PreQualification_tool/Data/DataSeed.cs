﻿using CC_PreQualification_tool.Models;
using Microsoft.AspNetCore.Hosting;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;

namespace CC_PreQualification_tool.Data
{
    public class DataSeed
    {
        private readonly CCPTDBContext _ctx;
        private readonly IWebHostEnvironment _hosting;

        public DataSeed(CCPTDBContext ctx, IWebHostEnvironment hosting)
        {
            _ctx = ctx;
            _hosting = hosting; 
        }

        public void Seed()
        {
            _ctx.Database.EnsureCreated();

            if (!_ctx.CreditCardType.Any())
            {
                // Need to create sample data
                var filepath = Path.Combine(_hosting.ContentRootPath, "Data/dataforCCType.json");
                var json = File.ReadAllText(filepath);
                var ccType = JsonConvert.DeserializeObject<IEnumerable<CreditCardType>>(json);
                _ctx.CreditCardType.AddRange(ccType);

                var type = _ctx.CreditCardType.Local.Any(y => y.Id == 0);
                if (type)
                {
                    _ctx.CreditCardType.AddRange(ccType);
                    _ctx.SaveChanges();
                }               

            }
        }
    }
}
