﻿using CC_PreQualification_tool.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CC_PreQualification_tool.Data
{
    public class CCPTDBContext : DbContext
    {
        public CCPTDBContext(DbContextOptions<CCPTDBContext> options) : base(options)
        {

        }
        public DbSet<Customer> Customer { get; set; }

        public DbSet<CreditCardType> CreditCardType { get; set; }

        public DbSet<CustomerCardDetails> CustomerCardDetails { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<Customer>()
              .Property(p => p.AnnualIncome)
              .HasColumnType("decimal(18,2)");

            builder.Entity<CreditCardType>()
              .Property(p => p.APR)
              .HasColumnType("decimal(18,2)");
        }
    }
}
