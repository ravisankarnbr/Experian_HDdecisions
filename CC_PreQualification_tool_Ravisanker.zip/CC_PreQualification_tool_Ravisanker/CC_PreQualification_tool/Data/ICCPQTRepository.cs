﻿using CC_PreQualification_tool.Models;
using System.Collections.Generic;


namespace CC_PreQualification_tool.Data
{
    /// <summary>
    /// Repository interface for Customer details and Customer Card details
    /// </summary>
    public interface ICCPQTRepository
    {
        IEnumerable<Customer> GetCustomerDetails();

        void AddCustomer(Customer customer);

        void AddCustomerCardDetails(CustomerCardDetails ccDetails);

        IEnumerable<CustomerCardDetails> GetCustomerCardDetails(long custCardId);

        IEnumerable<CreditCardType> GetCardTypes();

        bool SaveAll();
    }
}
