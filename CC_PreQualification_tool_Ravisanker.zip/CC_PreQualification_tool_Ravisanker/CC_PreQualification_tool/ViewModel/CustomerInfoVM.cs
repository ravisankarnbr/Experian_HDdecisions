﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CC_PreQualification_tool.ViewModel
{
    /// <summary>
    /// View Model class for Customer Card details
    /// </summary>
    public class CustomerCardDetailsVM
    {
        public long Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public decimal APR { get; set; }

        public bool IsEligible { get; set; }

        public string Message { get; set; }

       
    }
}
