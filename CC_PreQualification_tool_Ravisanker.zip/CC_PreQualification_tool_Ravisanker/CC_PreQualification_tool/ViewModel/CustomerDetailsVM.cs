﻿using CC_PreQualification_tool.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CC_PreQualification_tool.ViewModel
{
    /// <summary>
    /// View Model class for Customer details
    /// </summary>
    public class CustomerDetailsVM
    {
        public int Id { get; set; }

        [Required]
        [DisplayName("First Name")]
        [MaxLength(25)]
        public string FirstName { get; set; }

        [Required]
        [DisplayName("Last Name")]
        [MaxLength(25)]
        public string LastName { get; set; }

        [Required]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]   
        [DataType(DataType.Date)]
        [DisplayName("DOB")]
        public DateTime DateOfBirth { get; set; }

        [Required]     
        [Range(0, 9999999.99, ErrorMessage = "Invalid Annual Income; Max 8 digits")]
        [DisplayName("Annual Income")]
        public decimal AnnualIncome { get; set; }

        public bool IsEligible {
            get
            {
                int age = 0;
                age = DateTime.Now.Year - DateOfBirth.Year;
                if (DateTime.Now.DayOfYear < DateOfBirth.DayOfYear)
                    age = age - 1;    


                if (age < CommonConstants.AgeLimit)
                    return false;
                else
                    return true;
            }

        }

        public string CardType
        {
            get
            {
                if (IsEligible && AnnualIncome > CommonConstants.MinSalary)
                    return CommonConstants.Barclaycard;
                else if (IsEligible && AnnualIncome < CommonConstants.MinSalary)
                    return CommonConstants.Vanquis;
                else
                    return string.Empty;
            }

        }

    }
    
}
