﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CC_PreQualification_tool.Models
{
    /// <summary>
    /// Abstract class for Models
    /// </summary>
    public abstract class ModelBase
    {
        public long Id { get; set; }

        public DateTime CreatedDate { get; set; }
    }
}
