﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CC_PreQualification_tool.Models
{
    /// <summary>
    /// Model class for card types
    /// </summary>
    public class CreditCardType 
    {
        public int Id { get; set; }
        public string CardName { get; set; }

        public decimal APR { get; set; }
    }
}
