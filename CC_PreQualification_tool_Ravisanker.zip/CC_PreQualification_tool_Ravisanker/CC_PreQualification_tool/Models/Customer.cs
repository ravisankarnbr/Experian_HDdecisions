﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CC_PreQualification_tool.Models
{
    /// <summary>
    /// Model class for Customer details
    /// </summary>
    public class Customer : ModelBase
    {
       
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public DateTime DoB { get; set; }

        public decimal AnnualIncome { get; set; }

        public bool IsEligible { get; set; }
    }
}
