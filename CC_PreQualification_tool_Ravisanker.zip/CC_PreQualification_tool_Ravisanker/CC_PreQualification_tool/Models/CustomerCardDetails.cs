﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CC_PreQualification_tool.Models
{
    /// <summary>
    /// Model class for Customer Card details
    /// </summary>
    public class CustomerCardDetails : ModelBase
    {

        [Required]
        [ForeignKey("Customer")]
        public long CustomerId { get; set; }
        public virtual Customer Customer { get; set; }

       
        [ForeignKey("CreditCardType")]
        public int? CardTypeId { get; set; }
        public virtual CreditCardType CreditCardType { get; set; }

        public string Message { get; set; }
    }
}
