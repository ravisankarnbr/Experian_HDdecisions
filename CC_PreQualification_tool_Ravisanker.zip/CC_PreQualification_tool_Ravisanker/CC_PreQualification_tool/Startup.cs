using CC_PreQualification_tool.Data;
using CC_PreQualification_tool.Service;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace CC_PreQualification_tool
{
    public class Startup
    {
        private readonly IConfiguration _Configuration;
        public Startup(IConfiguration configuration)
        {
            _Configuration = configuration;
        }

             
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<CCPTDBContext>(x =>
            {
                x.UseSqlServer(_Configuration.GetConnectionString("CCPTDBConnection"));
            });
            services.AddTransient<DataSeed>();
            services.AddScoped<ICCPQTRepository, CCPQTRepository>();  
            services.AddScoped<ICustomerService, CustomerService>();
            services.AddControllersWithViews();
        }


        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
           
          
            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Customer}/{action=Index}/{id?}");
            });
        }
    }
}
