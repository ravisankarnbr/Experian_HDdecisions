﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CC_PreQualification_tool.Common
{
    public static class CommonConstants
    {
        // To check the Age 
        public static int AgeLimit => 18;

        //To check the Salary for Barclay card
        public static int MinSalary => 30000;
        
        public static string Barclaycard => "Barclaycard Credit Card";
        public static string Vanquis => "Vanquis Credit Card";

        //Common message for Card Eligibility 
        public static string EligibleMessage => "You are eligible for ";

        // Message for Non Eligible condition
        public static string NonEligibleMessage => "No credit cards are available’";

    }
}
