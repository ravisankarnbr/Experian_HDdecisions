﻿using CC_PreQualification_tool.Common;
using CC_PreQualification_tool.Data;
using CC_PreQualification_tool.Models;
using CC_PreQualification_tool.ViewModel;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CC_PreQualification_tool.Service
{
    /// <summary>
    /// Interface for Customer 
    /// </summary>
    public interface ICustomerService
    {
       
        long SaveCustomerData(CustomerDetailsVM CustInfo);

        
        CustomerCardDetailsVM GetCustomerCardDetails(long custCardId);
    }


    ///<inheritdoc cref="ICustomerService"/>
    public class CustomerService : ICustomerService
    {
       
        private readonly ICCPQTRepository _toolRepository;
        private readonly ILogger<CustomerService> _logger;

        public CustomerService(ICCPQTRepository CCRepository, ILogger<CustomerService> logger)
        {
            _toolRepository = CCRepository;
            _logger = logger;
           
        }

        /// <summary>
        /// Concreate method for getting Customer and Card details 
        /// </summary>
        /// <param name="custCardId"></param>
        /// <returns>CustomerCard details</returns>
        public CustomerCardDetailsVM GetCustomerCardDetails(long custCardId)
        {
            CustomerCardDetailsVM card = new CustomerCardDetailsVM();
            try
            {
                if (custCardId != 0)
                {

                    var cardDetails = _toolRepository.GetCustomerCardDetails(custCardId).FirstOrDefault();

                    card = new CustomerCardDetailsVM
                    {
                        FirstName = cardDetails.Customer.FirstName,
                        LastName = cardDetails.Customer.LastName,
                        Message = cardDetails.Message,
                        APR = cardDetails.CreditCardType != null ? cardDetails.CreditCardType.APR : 0,
                        IsEligible = cardDetails.Customer.IsEligible

                    };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to get Customer card details: {ex}");

            }

            return card;
        }

        /// <summary>
        /// Concreate method for Adding Customer and Card details 
        /// </summary>
        /// <param name="CustInfo"></param>
        /// <returns>created record Id</returns>
        public long SaveCustomerData(CustomerDetailsVM CustInfo)
        {
            
           CustomerCardDetails card = new CustomerCardDetails();
            try
            {
                if (CustInfo != null)
                {
                    Customer customer = new Customer
                    {
                        FirstName = CustInfo.FirstName,
                        LastName = CustInfo.LastName,
                        DoB = CustInfo.DateOfBirth,
                        AnnualIncome = CustInfo.AnnualIncome,
                        IsEligible = CustInfo.IsEligible,
                        CreatedDate = DateTime.Now.Date

                    };

                    _toolRepository.AddCustomer(customer);

                    _toolRepository.SaveAll();
                    _logger.LogInformation("Save Customer");

                    var cardType = _toolRepository.GetCardTypes().Where(x => x.CardName == CustInfo.CardType).Select(x => x).FirstOrDefault();
                    card = new CustomerCardDetails
                    {
                        CardTypeId = cardType?.Id,
                        CustomerId = customer.Id,
                        Message = CustInfo.IsEligible ? CommonConstants.EligibleMessage + ' ' + cardType.CardName : CommonConstants.NonEligibleMessage,
                        CreatedDate = DateTime.Now.Date,

                    };

                    _toolRepository.AddCustomerCardDetails(card);

                    _toolRepository.SaveAll();

                    _logger.LogInformation("Save CustomerCardDetails");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to Save: {ex}");

            }
            return card != null ? card.Id : 0;
            }            

        }
    }
    

