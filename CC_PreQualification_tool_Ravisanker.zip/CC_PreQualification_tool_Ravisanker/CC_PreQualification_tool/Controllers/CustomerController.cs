﻿
using CC_PreQualification_tool.Service;
using CC_PreQualification_tool.ViewModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System;

namespace Experian.Web.Controllers
{
    public class CustomerController : Controller
    {
        private readonly ICustomerService _customerService;

        /// <summary>
        /// Constructor Injection
        /// </summary>      
        /// <see cref="ICustomerService"/>  
        public CustomerController(ICustomerService customerService)
        {
            _customerService = customerService;
        }

        /// <summary>
        /// Landing page Index
        /// </summary>
        /// <returns></returns>
        public IActionResult Index()
        {
           
            return View();
        }

        /// <summary>
        /// Returns the CustomerDetailsVM object when the form is submitted
        /// </summary>
        /// <param name="customer"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Index(CustomerDetailsVM customer)
        {
            long custCardId = 0;            
            CustomerDetailsVM newCustomer = new CustomerDetailsVM();
            if (ModelState.IsValid)
            {
                //Calling Save method - To Add customer details to DB, after successful insertion it will return the newly created record Id
                custCardId = _customerService.SaveCustomerData(customer);
            }
          
            if (custCardId > 0)
            {
                /* Get the Customer card details from DB for the newly created record,
                which is passed to the CardResult view for displaying the details */
                var custCardDetails = _customerService.GetCustomerCardDetails(custCardId);
                return View("CardResult", custCardDetails);
            }
            else
            {
                return View(nameof(Index));
            }
        }

        /// <summary>
        /// Navigates to the CreditCard view for displaying the message after validation
        /// </summary>
        /// <returns></returns>
        public IActionResult CreditCard()
        {
            return View();
        }
    }
}