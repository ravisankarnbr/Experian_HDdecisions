﻿using CC_PreQualification_tool.Data;
using CC_PreQualification_tool.Test.Common;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace CC_PreQualification_tool.Test
{
    public class DBFixture
    {
        /// <summary>
        /// Read Connection string from Config.json file
        /// </summary>
       public ServiceProvider ServiceProvider { get; private set; }
        public DBFixture()
        {

           
           var services = new ServiceCollection();

                 
            var config = new ConfigurationBuilder()
               .AddJsonFile("Config.json")
               .Build();
            var connectionString = config.GetConnectionString("CCPTDBConnection");

            services
            .AddDbContext<CCPTDBContext>(options => options.UseSqlServer(connectionString),
                ServiceLifetime.Transient);
            ServiceProvider = services.BuildServiceProvider();



        }

 

    }
}
