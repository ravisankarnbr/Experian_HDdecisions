﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CC_PreQualification_tool.Test.Common
{
    
        public static class TestConstants
        {
            public static string BarclayEligibleMessage => "You are eligible for  Barclaycard Credit Card";
            public static string VanquisEligibleMessage => "You are eligible for  Vanquis Credit Card";

            public static string NonEligibleMessage => "No credit cards are available’";

           

        }
   
}
