using CC_PreQualification_tool.Data;
using CC_PreQualification_tool.Models;
using CC_PreQualification_tool.Service;
using CC_PreQualification_tool.Test.Common;
using CC_PreQualification_tool.Test.Mock;

using Experian.Web.Controllers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;

using Xunit;

namespace CC_PreQualification_tool.Test
{

    public class CustomerCardTest : IClassFixture<DBFixture>
    {
        private ServiceProvider _serviceProvide;
    

        public CustomerCardTest(DBFixture fixture)
        {
            _serviceProvide = fixture.ServiceProvider;
        }

        [Fact]
        //Index method result is a view
        public void IndexUnitTest()
        {
            //arrange
            var mockRepo = new Mock<ICustomerService>();
            CustomerController cController = new Experian.Web.Controllers.CustomerController(mockRepo.Object);

            //act
            IActionResult result = cController.Index();

            //assert
            Assert.IsType<ViewResult>(result);
        }
        

       [Fact]
        public void IndexWithParameterTest()
        {
            //arrange
            var mockRepo = new Mock<ICustomerService>();
            var controller = new CustomerController(mockRepo.Object);
            var mockContext = new Mock<CCPTDBContext>();
            var mockSet = new Mock<DbSet<Customer>>();


            //act
            var result = controller.Index(MockCustomerDetails.GetCustomerDetailsforVanquis());


            //assert           
            Assert.IsType<ViewResult>(result);

        }

        // Test for Vanquis Card
        [Fact]
        public void SaveCustomerDataTestForVanquis()
        {

            using (var context = _serviceProvide.GetService<CCPTDBContext>())
            {

                // Arrange           
                var mockRepoLogger = new Mock<ILogger<CCPQTRepository>>().Object;
                var mockCustomerServiceLogger = new Mock<ILogger<CustomerService>>().Object;
                ICCPQTRepository customerRepository = new CCPQTRepository(context, mockRepoLogger);  
                var customerService = new CustomerService(customerRepository, mockCustomerServiceLogger);



                //Act
                var saveResult = customerService.SaveCustomerData(MockCustomerDetails.GetCustomerDetailsforVanquis());
                var cardDetails = customerService.GetCustomerCardDetails(saveResult);



                // Assert
                 Assert.NotNull(cardDetails);               
                Assert.Equal(TestConstants.VanquisEligibleMessage, cardDetails.Message);


            }
            

        }


        // Test for Barclay Card
        [Fact]
        public void SaveCustomerDataTestForBarclay()
        {

            using (var context = _serviceProvide.GetService<CCPTDBContext>())
            {

                // Arrange           
                var mockRepoLogger = new Mock<ILogger<CCPQTRepository>>().Object;
                var mockCustomerServiceLogger = new Mock<ILogger<CustomerService>>().Object;
                ICCPQTRepository customerRepository = new CCPQTRepository(context, mockRepoLogger);
                var customerService = new CustomerService(customerRepository, mockCustomerServiceLogger);



                //Act
                var saveResult = customerService.SaveCustomerData(MockCustomerDetails.GetCustomerDetailsforBarclaycard());
                var cardDetails = customerService.GetCustomerCardDetails(saveResult);



                // Assert
                Assert.NotNull(cardDetails);
                Assert.Equal(TestConstants.BarclayEligibleMessage, cardDetails.Message);


            }


        }



        // Test for No Cards
        [Fact]
        public void SaveCustomerDataTestForNoCard()
        {

            using (var context = _serviceProvide.GetService<CCPTDBContext>())
            {

                // Arrange           
                var mockRepoLogger = new Mock<ILogger<CCPQTRepository>>().Object;
                var mockCustomerServiceLogger = new Mock<ILogger<CustomerService>>().Object;
                ICCPQTRepository customerRepository = new CCPQTRepository(context, mockRepoLogger);
                var customerService = new CustomerService(customerRepository, mockCustomerServiceLogger);

                //Act
                var saveResult = customerService.SaveCustomerData(MockCustomerDetails.GetCustomerDetailsforNoCard());
                var cardDetails = customerService.GetCustomerCardDetails(saveResult);

                // Assert
                Assert.NotNull(cardDetails);
                Assert.Equal(TestConstants.NonEligibleMessage, cardDetails.Message);


            }


        }
    }
    
}
