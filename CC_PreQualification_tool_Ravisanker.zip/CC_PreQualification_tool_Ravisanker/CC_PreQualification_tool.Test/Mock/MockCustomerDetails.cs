﻿using CC_PreQualification_tool.ViewModel;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace CC_PreQualification_tool.Test.Mock
{
    public class MockCustomerDetails
    {

       
        public static CustomerDetailsVM GetCustomerDetailsforVanquis()
        {
            CultureInfo culture = new CultureInfo("en-GB");

            var _customer = new CustomerDetailsVM()
            {
                Id = 0,
                FirstName = "James",
                LastName = "Smith",
                DateOfBirth = Convert.ToDateTime("01/03/1990 12:10:15 PM", culture),
                AnnualIncome = 25630

            };

            return _customer;
        }


        public static CustomerDetailsVM GetCustomerDetailsforBarclaycard()
        {
            CultureInfo culture = new CultureInfo("en-GB");
            var _customer = new CustomerDetailsVM()
            {
                Id = 0,
                FirstName = "Michael",
                LastName = "Smith",
                DateOfBirth = Convert.ToDateTime("12/07/2000 11:00:00 PM", culture),               
                AnnualIncome = 30001

            };

            return _customer;
        }


        public static CustomerDetailsVM GetCustomerDetailsforNoCard()
        {
            CultureInfo culture = new CultureInfo("en-GB");
            var _customer = new CustomerDetailsVM()
            {
                Id = 0,
                FirstName = "Maria",
                LastName = "Garcia",
                DateOfBirth = Convert.ToDateTime("01/05/2005 11:00:00 PM", culture),                
                AnnualIncome = 500

            };

            return _customer;
        }


        public static CustomerDetailsVM GetCustomerDetailsforInvalidDoB()
        {
            CultureInfo culture = new CultureInfo("en-GB");
            var _customer = new CustomerDetailsVM()
            {
                Id = 0,
                FirstName = "David",
                LastName = "Smith",
                DateOfBirth = Convert.ToDateTime("13/05/2003 10:00:00 PM", culture),                
                AnnualIncome = 60000

            };

            return _customer;
        }
    }
}
